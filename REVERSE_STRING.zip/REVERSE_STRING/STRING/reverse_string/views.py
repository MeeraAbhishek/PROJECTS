from django.shortcuts import render

# Create your views here.
from django.utils.html import escape

def reverse_string(request):
    reversed_string = None
    if request.method == 'POST':
        input_string = request.POST.get('text', '')
        # Escape the input string to prevent XSS attacks
        input_string_escaped = escape(input_string)
        reversed_string = input_string_escaped[::-1]
    return render(request, 'reverse_string.html', {'reversed_string': reversed_string})
