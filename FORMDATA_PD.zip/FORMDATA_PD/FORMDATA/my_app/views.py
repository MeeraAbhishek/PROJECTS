from django.shortcuts import render
from .forms import MyForm
from .models import MyModel

def my_view(request):
    my_instance = MyModel.objects.first()  # Get the first instance of MyModel
    form = MyForm(instance=my_instance)
    return render(request, 'my_template.html', {'form': form})
