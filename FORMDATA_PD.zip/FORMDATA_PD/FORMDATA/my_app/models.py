

# Create your models here.
from django.db import models

class MyModel(models.Model):
    field1 = models.CharField(max_length=100)
    field2 = models.CharField(max_length=100)
    field3 = models.TextField()

    def __str__(self):
        return self.field1  # Return a string representation of the model instance
